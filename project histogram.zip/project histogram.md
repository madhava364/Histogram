```python
import numpy as np
import matplotlib.pyplot as plt
from skimage import io

im=io.imread('hum.jpg')
fig=plt.figure(figsize =(10, 16))


plt.subplot(3,1,1)
plt.hist(im[:,:,0].ravel(),256,color='red')
plt.xlabel('frequency   ')
plt.ylabel('intensities')
plt.title('channel 0')

plt.subplot(3,1,2)
plt.hist(im[:,:,1].ravel(),256,color='blue')
plt.xlabel('frequency')
plt.ylabel('intensities')
plt.title('channel 1')

plt.subplot(3,1,3)
plt.hist(im[:,:,2].ravel(),256,color='green')
plt.xlabel('frequency')
plt.ylabel('intensities')
plt.title('channel 2')

plt.tight_layout()
plt.show()
```


    
![png](output_0_0.png)
    



```python
fig=plt.figure(figsize =(10, 4))
ax = fig.add_axes([0.1, 0.1, 0.8, 0.8])
ax.hist(im[:,:,0].ravel(),256,color='red',density=False)
ax.set_xlabel('frequency')
ax.set_ylabel('intensities')
ax.set_title('channel 0')
plt.show()
```


    
![png](output_1_0.png)
    



```python
plt.hist([1,2,3,4,5,6,7,8,9,10],5,edgecolor='red')
```




    (array([2., 2., 2., 2., 2.]),
     array([ 1. ,  2.8,  4.6,  6.4,  8.2, 10. ]),
     <BarContainer object of 5 artists>)




    
![png](output_2_1.png)
    



```python
import matplotlib.image as im
tx=im.imread('hum.jpg')
plt.imshow(tx[:,:,])

plt.show()
```


    
![png](output_3_0.png)
    



```python

```


```python

```
